function SpotifyController()
{
    Controller.call( this, 'Spotify', '#84bd00' );
}

SpotifyController.prototype = Object.create( Controller.prototype );
SpotifyController.prototype.constructor = SpotifyController;

SpotifyController.prototype.play = function()
{
    $( '#play-pause' ).click();
};

SpotifyController.prototype.pause = function()
{
    $( '#play-pause' ).click();
};

SpotifyController.prototype.getProgress = function()
{
    var currentTrackTime = trackTimeToSeconds( $( '#track-current' ).text() );
    var trackLength = trackTimeToSeconds( $( '#track-length' ).text() );

    var progress = trackLength === 0 ? 0 : currentTrackTime / trackLength;

    return progress
};

SpotifyController.prototype.checkIfPaused = function()
{
    return !$( '#play-pause' ).hasClass( 'playing' );
};

SpotifyController.prototype.getContentInfo = function()
{
    var track = $( '#track-name>a' ).text();
    var artist = $( '#track-artist>a' ).map( function()
        {
            return $( this ).text();
        } ).get().join( ', ' );
    var artwork = $( '#cover-art div.sp-image-img' ).css( 'background-image' ).replace( /^.*\s*url\(\s*[\'\"]?/, '' ).replace( /[\'\"]?\s*\).*/, '' );
    if( track )
    {
        return new ContentInfo( track, artist, "", artwork );
    }
    else
    {
        return null;
    }
};


$( window ).ready( function()
{
    if( $( '#progress' ).length !== 0 && $( '#play-pause' ).length !== 0 )
    {
        var controller = new SpotifyController();
        controller.startPolling();
    }
} );